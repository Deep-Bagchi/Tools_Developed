1.Create a folder called "KnowledgeInbox" under "C:\Program Files\" 
2.Run the Instal file under "C:\Program Files\KnowledgeInbox\ScreenCapture API\install.vbs"